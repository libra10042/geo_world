declare namespace _default {
    let POSTRENDER: string;
    let MOVESTART: string;
    let MOVEEND: string;
    let LOADSTART: string;
    let LOADEND: string;
}
export default _default;
/**
 * *
 */
export type Types = "postrender" | "movestart" | "moveend" | "loadstart" | "loadend";
//# sourceMappingURL=MapEventType.d.ts.map