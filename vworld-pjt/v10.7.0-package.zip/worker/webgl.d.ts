export function create(): Worker;
//# sourceMappingURL=webgl.d.ts.map