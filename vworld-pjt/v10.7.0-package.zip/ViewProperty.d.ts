declare namespace _default {
    let CENTER: string;
    let RESOLUTION: string;
    let ROTATION: string;
}
export default _default;
//# sourceMappingURL=ViewProperty.d.ts.map